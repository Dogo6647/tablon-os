class CamSnap {
  constructor(runtime) {
    this.runtime = runtime;
    this.uniq = Date.now();
    this.videoElement = null;
  }

  getInfo() {
    return {
      id: 'camsnap',
      name: 'Camera Plus',
      blocks: [
        {
          opcode: 'cheese',
          blockType: Scratch.BlockType.REPORTER,
          text: 'Take a picture as base64'
        }
      ]
    };
  }

  async initializeVideoElement() {
    const video = document.createElement('video');
    video.width = 640;
    video.height = 480;
    video.autoplay = true;
    video.playsinline = true;
    video.style.display = 'none';

    await new Promise((resolve) => {
      video.addEventListener('loadeddata', () => {
        resolve();
      });

      video.addEventListener('error', () => {
        resolve();
      });

      navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
        video.srcObject = stream;
      }).catch(() => {
        resolve();
      });
    });

    this.videoElement = video;
  }

  async cheese() {
    if (!this.videoElement) {
      await this.initializeVideoElement();
    }

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.width = this.videoElement.videoWidth;
    canvas.height = this.videoElement.videoHeight;
    context.drawImage(this.videoElement, 0, 0);

    return canvas.toDataURL('image/jpeg');
  }
}

Scratch.extensions.register(new CamSnap());
