class VideoRecorderExtension {
  constructor(runtime) {
    this.runtime = runtime;
    this.mediaRecorder = null;
    this.chunks = [];
    this.recordingInProgress = false;
    this.recordedVideo = null;
  }

  getInfo() {
    return {
      id: 'videoRecorder',
      name: 'Video Recorder',
      blocks: [
        {
          opcode: 'startRecording',
          blockType: Scratch.BlockType.COMMAND,
          text: 'start recording video'
        },
        {
          opcode: 'stopRecording',
          blockType: Scratch.BlockType.COMMAND,
          text: 'stop recording'
        },
        {
          opcode: 'downloadVideo',
          blockType: Scratch.BlockType.COMMAND,
          text: 'download recorded video'
        }
      ]
    };
  }

  startRecording() {
    if (this.recordingInProgress) {
      return;
    }

    navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then((stream) => {
      this.mediaRecorder = new MediaRecorder(stream);
      this.mediaRecorder.addEventListener('dataavailable', (e) => {
        this.chunks.push(e.data);
      });
      this.mediaRecorder.start();
      this.recordingInProgress = true;
    }).catch((error) => {
      console.error('Error accessing webcam:', error);
    });
  }

  stopRecording() {
    if (this.mediaRecorder && this.recordingInProgress) {
      this.mediaRecorder.stop();
      this.mediaRecorder = null;
      this.recordingInProgress = false;
    }
  }

  downloadVideo() {
    if (this.chunks.length === 0) {
      return;
    }

    const blob = new Blob(this.chunks, { type: 'video/mp4' });
    this.chunks = [];

    const recordedVideo = URL.createObjectURL(blob);

    const currentDateTime = new Date().toISOString().split('T')[0]; // Get the current date in YYYY-MM-DD format

    const a = document.createElement('a');
    a.href = recordedVideo;
    a.download = `${currentDateTime}.mp4`;
    a.click();
  }
}

Scratch.extensions.register(new VideoRecorderExtension());
